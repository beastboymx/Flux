


import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.TimeZone;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author oscar.lopez
 */
public class F extends javax.swing.JFrame {

    /**
     * Creates new form F
     */
    public F() {
        initComponents();
        
        setIconImage(getIconImage());
        //Centrar pantalla
        Dimension pantalla = Toolkit.getDefaultToolkit().getScreenSize();
        //Asignar valores a la ventana
        setLocationRelativeTo(null);		
        setVisible(true);
      //Bloqueo de maximizar ventana
        this.setResizable(false);
        Ola();
        
        jComboBox1.setSelectedItem(null);
        tfnombre.setText(System.getProperty("user.name"));
    }
    
    
    @Override
    public Image getIconImage(){
         Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Img/fd2.png"));
         
         
         return retValue;
    }
    
    
    public void Ola(){
        
        String filepath = "O:\\Department\\FluxDeposition\\Maya\\olas.txt";
        File file = new File(filepath);
        
        try{
        BufferedReader br = new BufferedReader(new FileReader(file));
        Object[] lines = br.lines().toArray();
        
        for(int i = 0; i <lines.length; i++){
            String line = lines[i].toString();
            jComboBox1.addItem(line);
        }
        }catch(FileNotFoundException ex){   
        }
        
    }
    
    
public void NF372() {
    DecimalFormat df = new DecimalFormat("#.0");
    Calendar Cal = Calendar.getInstance(TimeZone.getTimeZone("GMT-6"));

    String sin = jtcon.getText();
    String con = jtsin.getText();
    String mod = jtmod.getText();
    String ola = jComboBox1.getSelectedItem() != null ? jComboBox1.getSelectedItem().toString() : ""; // Manejo de null
    String nombre = System.getProperty("user.name"); // Obtener el nombre del usuario de la sesión de Windows
    String wo = tfwo.getText();
    String stro = Strok.getText();
    String valv = Valv.getText();

    // Validaciones de campos vacíos
    if (sin.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'sin flux'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return; // Salir del método si hay un campo vacío
    } else if (con.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'con flux'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (mod.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'modelo'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (ola.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Selecciona una opción en 'ola'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (wo.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'Tank pressure'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (stro.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'Strok factor'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (valv.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'Valve factor'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    }

    // Convertir los valores a float
    float x = Float.parseFloat(sin);
    float y = Float.parseFloat(con);
    float f = 4;
    float a = 80;
    double ps = f / 100;
    float xy = x - y;
    double r = xy / a * ps * 1000000;
    String Fe = Cal.get(Cal.DATE) + "/" + (Cal.get(Cal.MONTH) + 1) + "/" + Cal.get(Cal.YEAR);
    String Ho = Cal.get(Cal.HOUR_OF_DAY) + ":" + Cal.get(Cal.MINUTE) + " ";

    // Mensaje de la cantidad de FLUX dispensada
    JOptionPane.showMessageDialog(null, "La cantidad de FLUX dispensada es:" + "\n" + "\n" + "                  " + df.format(r) + "  microgramos/pulgada2");

    try {
        // Escribir en el archivo CSV
        FileWriter Writer = new FileWriter("O:\\Department\\FluxDeposition\\Maya\\FluxNF372.csv", true);
        
        // Registro en el orden deseado
        String registro = nombre + ", " + Fe + ", " + Ho + ", " + ola + ", " + df.format(r) + ", " + wo + ", " + stro + ", " + valv;
        Writer.write(registro);
        Writer.write(System.getProperty("line.separator"));
        Writer.close();
        
        JOptionPane.showMessageDialog(null, "Registro completado");

        // Limpiar campos
        jtcon.setText("");
        jtsin.setText("");
      } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al registrar");
    }
}
    
    public void HF159(){
    DecimalFormat df = new DecimalFormat("#.0");
    Calendar Cal = Calendar.getInstance(TimeZone.getTimeZone("GMT-6"));

    String sin = jtcon.getText();
    String con = jtsin.getText();
    String mod = jtmod.getText();
    String ola = jComboBox1.getSelectedItem() != null ? jComboBox1.getSelectedItem().toString() : ""; // Manejo de null
    String nombre = System.getProperty("user.name"); // Obtener el nombre del usuario de la sesión de Windows
    String wo = tfwo.getText();
    String stro = Strok.getText();
    String valv = Valv.getText();

    // Validaciones de campos vacíos
    if (sin.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'sin flux'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return; // Salir del método si hay un campo vacío
    } else if (con.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'con flux'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (mod.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'modelo'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (ola.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Selecciona una opción en 'ola'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (wo.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'Tank pressure'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (stro.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'Strok factor'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (valv.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'Valve factor'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    }

    // Convertir los valores a float
    float x = Float.parseFloat(sin);
    float y = Float.parseFloat(con);
    float f = 4;
    float a = 80;
    double ps = f / 100;
    float xy = x - y;
    double r = xy / a * ps * 1000000;
    String Fe = Cal.get(Cal.DATE) + "/" + (Cal.get(Cal.MONTH) + 1) + "/" + Cal.get(Cal.YEAR);
    String Ho = Cal.get(Cal.HOUR_OF_DAY) + ":" + Cal.get(Cal.MINUTE) + " ";

    // Mensaje de la cantidad de FLUX dispensada
    JOptionPane.showMessageDialog(null, "La cantidad de FLUX dispensada es:" + "\n" + "\n" + "                  " + df.format(r) + "  microgramos/pulgada2");

    try {
        // Escribir en el archivo CSV
        FileWriter Writer = new FileWriter("O:\\Department\\FluxDeposition\\Maya\\FluxHF159.csv", true);
        
        // Registro en el orden deseado
        String registro = nombre + ", " + Fe + ", " + Ho + ", " + ola + ", " + df.format(r) + ", " + wo + ", " + stro + ", " + valv;
        Writer.write(registro);
        Writer.write(System.getProperty("line.separator"));
        Writer.close();
        
        JOptionPane.showMessageDialog(null, "Registro completado");

        // Limpiar campos
        jtcon.setText("");
        jtsin.setText("");
      } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al registrar");
    }
}

    
public void HF6850(){
    DecimalFormat df = new DecimalFormat("#.0");
    Calendar Cal = Calendar.getInstance(TimeZone.getTimeZone("GMT-6"));

    String sin = jtcon.getText();
    String con = jtsin.getText();
    String mod = jtmod.getText();
    String ola = jComboBox1.getSelectedItem() != null ? jComboBox1.getSelectedItem().toString() : ""; // Manejo de null
    String nombre = System.getProperty("user.name"); // Obtener el nombre del usuario de la sesión de Windows
    String wo = tfwo.getText();
    String stro = Strok.getText();
    String valv = Valv.getText();

    // Validaciones de campos vacíos
    if (sin.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'sin flux'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return; // Salir del método si hay un campo vacío
    } else if (con.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'con flux'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (mod.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'modelo'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (ola.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Selecciona una opción en 'ola'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (wo.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'Tank pressure'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (stro.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'Strok factor'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (valv.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'Valve factor'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    }

    // Convertir los valores a float
    float x = Float.parseFloat(sin);
    float y = Float.parseFloat(con);
    float f = 4;
    float a = 80;
    double ps = f / 100;
    float xy = x - y;
    double r = xy / a * ps * 1000000;
    String Fe = Cal.get(Cal.DATE) + "/" + (Cal.get(Cal.MONTH) + 1) + "/" + Cal.get(Cal.YEAR);
    String Ho = Cal.get(Cal.HOUR_OF_DAY) + ":" + Cal.get(Cal.MINUTE) + " ";

    // Mensaje de la cantidad de FLUX dispensada
    JOptionPane.showMessageDialog(null, "La cantidad de FLUX dispensada es:" + "\n" + "\n" + "                  " + df.format(r) + "  microgramos/pulgada2");

    try {
        // Escribir en el archivo CSV
        FileWriter Writer = new FileWriter("O:\\Department\\FluxDeposition\\Maya\\Flux959.csv", true);
        
        // Registro en el orden deseado
        String registro = nombre + ", " + Fe + ", " + Ho + ", " + ola + ", " + df.format(r) + ", " + wo + ", " + stro + ", " + valv;
        Writer.write(registro);
        Writer.write(System.getProperty("line.separator"));
        Writer.close();
        
        JOptionPane.showMessageDialog(null, "Registro completado");

        // Limpiar campos
        jtcon.setText("");
        jtsin.setText("");
      } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al registrar");
    }
}

public void BF2220(){
    DecimalFormat df = new DecimalFormat("#.0");
    Calendar Cal = Calendar.getInstance(TimeZone.getTimeZone("GMT-6"));

    String sin = jtcon.getText();
    String con = jtsin.getText();
    String mod = jtmod.getText();
    String ola = jComboBox1.getSelectedItem() != null ? jComboBox1.getSelectedItem().toString() : ""; // Manejo de null
    String nombre = System.getProperty("user.name"); // Obtener el nombre del usuario de la sesión de Windows
    String wo = tfwo.getText();
    String stro = Strok.getText();
    String valv = Valv.getText();

    // Validaciones de campos vacíos
    if (sin.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'sin flux'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return; // Salir del método si hay un campo vacío
    } else if (con.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'con flux'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (mod.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'modelo'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (ola.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Selecciona una opción en 'ola'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (wo.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'Tank pressure'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (stro.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'Strok factor'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (valv.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'Valve factor'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    }

    // Convertir los valores a float
    float x = Float.parseFloat(sin);
    float y = Float.parseFloat(con);
    float f = 4;
    float a = 80;
    double ps = f / 100;
    float xy = x - y;
    double r = xy / a * ps * 1000000;
    String Fe = Cal.get(Cal.DATE) + "/" + (Cal.get(Cal.MONTH) + 1) + "/" + Cal.get(Cal.YEAR);
    String Ho = Cal.get(Cal.HOUR_OF_DAY) + ":" + Cal.get(Cal.MINUTE) + " ";

    // Mensaje de la cantidad de FLUX dispensada
    JOptionPane.showMessageDialog(null, "La cantidad de FLUX dispensada es:" + "\n" + "\n" + "                  " + df.format(r) + "  microgramos/pulgada2");

    try {
        // Escribir en el archivo CSV
        FileWriter Writer = new FileWriter("O:\\Department\\FluxDeposition\\Maya\\FluxVF2220.csv", true);
        
        // Registro en el orden deseado
        String registro = nombre + ", " + Fe + ", " + Ho + ", " + ola + ", " + df.format(r) + ", " + wo + ", " + stro + ", " + valv;
        Writer.write(registro);
        Writer.write(System.getProperty("line.separator"));
        Writer.close();
        
        JOptionPane.showMessageDialog(null, "Registro completado");

        // Limpiar campos
        jtcon.setText("");
        jtsin.setText("");
      } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al registrar");
    }
}

public void NR330(){
            DecimalFormat df = new DecimalFormat("#.0");
    Calendar Cal = Calendar.getInstance(TimeZone.getTimeZone("GMT-6"));

    String sin = jtcon.getText();
    String con = jtsin.getText();
    String mod = jtmod.getText();
    String ola = jComboBox1.getSelectedItem() != null ? jComboBox1.getSelectedItem().toString() : ""; // Manejo de null
    String nombre = System.getProperty("user.name"); // Obtener el nombre del usuario de la sesión de Windows
    String wo = tfwo.getText();
    String stro = Strok.getText();
    String valv = Valv.getText();

    // Validaciones de campos vacíos
    if (sin.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'sin flux'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return; // Salir del método si hay un campo vacío
    } else if (con.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'con flux'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (mod.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'modelo'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (ola.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Selecciona una opción en 'ola'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (wo.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'Tank pressure'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (stro.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'Strok factor'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (valv.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'Valve factor'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    }

    // Convertir los valores a float
    float x = Float.parseFloat(sin);
    float y = Float.parseFloat(con);
    float f = 4;
    float a = 80;
    double ps = f / 100;
    float xy = x - y;
    double r = xy / a * ps * 1000000;
    String Fe = Cal.get(Cal.DATE) + "/" + (Cal.get(Cal.MONTH) + 1) + "/" + Cal.get(Cal.YEAR);
    String Ho = Cal.get(Cal.HOUR_OF_DAY) + ":" + Cal.get(Cal.MINUTE) + " ";

    // Mensaje de la cantidad de FLUX dispensada
    JOptionPane.showMessageDialog(null, "La cantidad de FLUX dispensada es:" + "\n" + "\n" + "                  " + df.format(r) + "  microgramos/pulgada2");

    try {
        // Escribir en el archivo CSV
        FileWriter Writer = new FileWriter("O:\\Department\\FluxDeposition\\Maya\\FluxNR330.csv", true);
        
        // Registro en el orden deseado
        String registro = nombre + ", " + Fe + ", " + Ho + ", " + ola + ", " + df.format(r) + ", " + wo + ", " + stro + ", " + valv;
        Writer.write(registro);
        Writer.write(System.getProperty("line.separator"));
        Writer.close();
        
        JOptionPane.showMessageDialog(null, "Registro completado");

        // Limpiar campos
        jtcon.setText("");
        jtsin.setText("");
      } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al registrar");
    }
}


public void NR330E(){
            DecimalFormat df = new DecimalFormat("#.0");
    Calendar Cal = Calendar.getInstance(TimeZone.getTimeZone("GMT-6"));

    String sin = jtcon.getText();
    String con = jtsin.getText();
    String mod = jtmod.getText();
    String ola = jComboBox1.getSelectedItem() != null ? jComboBox1.getSelectedItem().toString() : ""; // Manejo de null
    String nombre = System.getProperty("user.name"); // Obtener el nombre del usuario de la sesión de Windows
    String wo = tfwo.getText();
    String stro = Strok.getText();
    String valv = Valv.getText();

    // Validaciones de campos vacíos
    if (sin.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'sin flux'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return; // Salir del método si hay un campo vacío
    } else if (con.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'con flux'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (mod.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'modelo'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (ola.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Selecciona una opción en 'ola'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (wo.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'Tank pressure'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (stro.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'Strok factor'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    } else if (valv.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Completa el campo de 'Valve factor'", "Datos Incompletos", JOptionPane.WARNING_MESSAGE);
        return;
    }

    // Convertir los valores a float
    float x = Float.parseFloat(sin);
    float y = Float.parseFloat(con);
    float f = 4;
    float a = 80;
    double ps = f / 100;
    float xy = x - y;
    double r = xy / a * ps * 1000000;
    String Fe = Cal.get(Cal.DATE) + "/" + (Cal.get(Cal.MONTH) + 1) + "/" + Cal.get(Cal.YEAR);
    String Ho = Cal.get(Cal.HOUR_OF_DAY) + ":" + Cal.get(Cal.MINUTE) + " ";

    // Mensaje de la cantidad de FLUX dispensada
    JOptionPane.showMessageDialog(null, "La cantidad de FLUX dispensada es:" + "\n" + "\n" + "                  " + df.format(r) + "  microgramos/pulgada2");

    try {
        // Escribir en el archivo CSV
        FileWriter Writer = new FileWriter("O:\\Department\\FluxDeposition\\Maya\\FluxNR330E.csv", true);
        
        // Registro en el orden deseado
        String registro = nombre + ", " + Fe + ", " + Ho + ", " + ola + ", " + df.format(r) + ", " + wo + ", " + stro + ", " + valv;
        Writer.write(registro);
        Writer.write(System.getProperty("line.separator"));
        Writer.close();
        
        JOptionPane.showMessageDialog(null, "Registro completado");

        // Limpiar campos
        jtcon.setText("");
        jtsin.setText("");
      } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al registrar");
    }
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        jtmod = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        tfnombre = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jtsin = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jtcon = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        tfwo = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        Strok = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        Valv = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("FluxDeposition 1.0.1");

        jLabel13.setText("  (500 - 1000)");

        jLabel14.setText("  Tolerancia");

        jLabel15.setText("  (1200)");

        jLabel16.setText("Este programa esta basado en la WI390");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        jtmod.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel18.setText("Modelo");

        jLabel19.setText("Ola (EIN)");

        jButton5.setText("NR330(STD)");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/fd.png"))); // NOI18N

        jButton6.setText("NR330(EXT)");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setText("CSV");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jLabel3.setText("Da click en el tipo de flux que estas usando.");

        jButton8.setText("WI390");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jLabel4.setText("  Tolerancia");

        tfnombre.setEditable(false);
        tfnombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tfnombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfnombreActionPerformed(evt);
            }
        });

        jLabel5.setText("(700 - 1200)");

        jLabel22.setText("Nombre");

        jLabel6.setText("  Tolerancia");

        jLabel7.setText("  (600 - 850)");

        jLabel8.setText("  Tolerancia");

        jLabel9.setText("(750 - 1500)");

        jLabel10.setText("  Tolerancia");

        jtsin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtsinActionPerformed(evt);
            }
        });

        jLabel1.setText("Peso inicial en gramos (Sin Flux)");

        jLabel2.setText("Peso final en gramos (Con Flux)");

        jButton1.setText("NF372");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("HF159");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("959");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("VF2220");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel11.setText(" (800 - 130)");

        jLabel12.setText("  Tolerancia");

        tfwo.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel20.setText("Tank Pressure");

        jButton9.setText("Ver Registros");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/inf.png"))); // NOI18N
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/p.png"))); // NOI18N

        Strok.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel24.setText("Stroke Factor");

        Valv.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Valv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ValvActionPerformed(evt);
            }
        });

        jLabel25.setText("Valve Factor");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jLabel22))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel20)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton8)
                            .addComponent(tfnombre, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfwo, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                        .addComponent(jLabel18)
                        .addGap(22, 22, 22)
                        .addComponent(jtmod, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(52, 52, 52)
                        .addComponent(jLabel19)
                        .addGap(18, 18, 18))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(jLabel24)
                        .addGap(16, 16, 16)
                        .addComponent(Strok, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(73, 73, 73)
                        .addComponent(jLabel25)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Valv, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(79, 79, 79))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(166, 166, 166)
                        .addComponent(jButton7)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addGap(3, 3, 3)
                                                    .addComponent(jLabel5))
                                                .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGap(18, 18, 18)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(18, 18, 18)
                                                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addGroup(layout.createSequentialGroup()
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                            .addGap(4, 4, 4)
                                                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGap(18, 18, 18)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addGap(18, 18, 18)
                                                    .addComponent(jButton4))
                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                    .addGap(18, 18, 18)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                            .addGap(18, 18, 18)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addGap(10, 10, 10)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jLabel13))
                                                    .addGap(48, 48, 48)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGroup(layout.createSequentialGroup()
                                                            .addGap(10, 10, 10)
                                                            .addComponent(jLabel15))))
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(jButton5)
                                                    .addGap(18, 18, 18)
                                                    .addComponent(jButton6))))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(158, 158, 158)
                                            .addComponent(jLabel3)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 191, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(110, 110, 110)
                                        .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(75, 75, 75))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jtcon)
                                    .addComponent(jtsin, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(235, 235, 235))))))
            .addGroup(layout.createSequentialGroup()
                .addGap(256, 256, 256)
                .addComponent(jLabel16)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton7)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtsin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtcon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtmod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18)
                    .addComponent(tfnombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfwo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20)
                    .addComponent(Strok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel24)
                    .addComponent(Valv, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel25))
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(jButton4)
                    .addComponent(jButton5)
                    .addComponent(jButton6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel6)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(jLabel8)
                            .addComponent(jLabel12))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(jLabel15)))
                    .addComponent(jLabel14)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel7)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel11)
                                .addComponent(jLabel9)))))
                .addGap(18, 18, 18)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton9)
                    .addComponent(jLabel23)
                    .addComponent(jButton8))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        try{
            Desktop.getDesktop().open(new File("O:\\Department\\FluxDeposition\\Maya"));
        }catch(IOException ex){

        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        try{
            Desktop.getDesktop().browse(new URI("https://pride.plexus.com/quality/secure/qdm/390%20-%20%20Process%20Work%20Instruction%20for%20Technical%20Wave%20Operations_RevAQ.docx"));
        }catch (Exception ex){
            JOptionPane.showMessageDialog(this, "Pagina no encontrada");
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void tfnombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfnombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfnombreActionPerformed

    private void jtsinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtsinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtsinActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        NF372();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        HF159();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        BF2220();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        HF6850();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
    NR330();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
    NR330E();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
    selec s = new selec();
    dispose();
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
    JOptionPane.showMessageDialog(null, "     Program Created by " + "\n" + "          Oscar Lopez" + "\n" + "\n" +"               Contact" + "\n" + "Oscar.Lopez@plexus.com");
    }//GEN-LAST:event_jButton10ActionPerformed

    private void ValvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ValvActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ValvActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
        public void run() {
            new F().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Strok;
    private javax.swing.JTextField Valv;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField jtcon;
    private javax.swing.JTextField jtmod;
    private javax.swing.JTextField jtsin;
    private javax.swing.JTextField tfnombre;
    private javax.swing.JTextField tfwo;
    // End of variables declaration//GEN-END:variables
}
